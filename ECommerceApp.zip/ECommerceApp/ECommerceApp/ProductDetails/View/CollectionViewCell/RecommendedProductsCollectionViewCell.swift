//
//  RecommendedProductsCollectionViewCell.swift
//  ECommerceApp
//
//  Created by APPLE on 04/02/23.
//

import UIKit

class RecommendedProductsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var labelProductTitle: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var baseViewProduct: UIView!
    @IBOutlet weak var labelProductDescription: UILabel!
    
    func setUpUIElements(productData : ProductListArray?) {
        self.baseViewProduct.addShadowForView()
        self.labelProductTitle.text = productData?.name ?? ""
        self.productImage.sd_setImage(with: URL(string: productData?.productUrl ?? ""))
        self.labelProductDescription.text = productData?.productDesc ?? ""
    }
}

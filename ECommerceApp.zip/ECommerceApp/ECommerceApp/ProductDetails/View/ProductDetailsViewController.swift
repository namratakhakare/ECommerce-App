//
//  ProductDetailsViewController.swift
//  ECommerceApp
//
//  Created by APPLE on 04/02/23.
//

import UIKit
import SDWebImage
class ProductDetailsViewController: UIViewController {

    @IBOutlet weak var baseViewProduct: UIView!
    @IBOutlet weak var labelProductDescription: UILabel!
    @IBOutlet weak var labelProductPrice: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var labelProductBrand: UILabel!
    @IBOutlet weak var labelProductOfferPrice: UILabel!
    @IBOutlet weak var buttonIncrementProduct: UIButton!
    @IBOutlet weak var buttonDecrementProduct: UIButton!
    @IBOutlet weak var labelProductCount: UILabel!
    @IBOutlet weak var collectionViewRecommendedProduct: UICollectionView!
    
    var recommendedProducts: [ProductListArray]? {
        didSet {
            DispatchQueue.main.async {
                self.setUpUiElements()
            }
        }
    }
    var selectedProductAtIndex: Int?
    var currentQuantity : Int = 1
    
//MARK: - View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.baseViewProduct.addShadowForView()
    }
    
    
    @IBAction func buttonAddTapped(_ sender: UIButton) {
        if currentQuantity < 10 {
            self.currentQuantity += 1
        }
        self.updateQuantity(quantity: self.currentQuantity)
    }
    
    @IBAction func buttonMinusTapped(_ sender: UIButton) {
        if currentQuantity > 1 {
            self.currentQuantity -= 1
        }
        updateQuantity(quantity: self.currentQuantity)
    }
    
    @IBAction func buttonAddToCart(_ sender: UIButton) {
        showToast(message: "Product has been successfully added to cart!")
    }
    
    func updateQuantity(quantity : Int) {
        self.labelProductCount.text = "\(quantity)"
    }
    
    func setUpUiElements() {
        DispatchQueue.main.async {
            self.productImage.sd_setImage(with: URL(string: self.recommendedProducts?[self.selectedProductAtIndex ?? 0].productUrl ?? ""))
            self.productName.text = self.recommendedProducts?[self.selectedProductAtIndex ?? 0].name ?? ""
            self.labelProductBrand.text = self.recommendedProducts?[self.selectedProductAtIndex ?? 0].brand ?? ""
            self.labelProductPrice.layer.sublayers?.removeAll()
            self.labelProductPrice.text = "Price : " +  (self.recommendedProducts?[self.selectedProductAtIndex ?? 0].price ?? "")
            self.labelProductPrice.addSlantLine(slantLineColor: .lightGray, slantLineWidth: 1,                                    startPoint:CGPoint(x: self.labelProductPrice.frame.width, y: 2),
                                                endPoint: CGPoint(x: 0, y: self.labelProductPrice.frame.height - 2))
            self.labelProductDescription.text = self.recommendedProducts?[self.selectedProductAtIndex ?? 0].productDesc ?? ""
            self.labelProductOfferPrice.text = "Offer Price : ₹ " +  (self.recommendedProducts?[self.selectedProductAtIndex ?? 0].offerPrice ?? "")
        }
        updateQuantity(quantity: 1)
    }
}

extension ProductDetailsViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return recommendedProducts?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecommendedProductsCollectionViewCell", for: indexPath) as! RecommendedProductsCollectionViewCell
        cell.setUpUIElements(productData: self.recommendedProducts?[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width / 1.2, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.selectedProductAtIndex = indexPath.item
        self.setUpUiElements()
    }
    
}

//
//  UserProfileViewModel.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import ObjectMapper

@objc protocol UserDetailsViewModelProtocol
{
    @objc optional
    func didFetchUserDetailsData(responseData: Any) -> Void
    @objc optional
    func didFailUserDetailsDataWithError(error: NSError) -> Void
}

class UserProfileViewModel : AppMainServiceDelegate {
    
    weak var delegate:UserDetailsViewModelProtocol?
    var message = ""
    
    static let sharedInstance :UserProfileViewModel =
    {
        let instance = UserProfileViewModel()
        return instance
    }()
    
    func didFetchData(responseData: Any) {
        self.delegate?.didFetchUserDetailsData?(responseData: responseData)
    }
    
    func didFailWithError(error: NSError) {
        self.delegate?.didFailUserDetailsDataWithError?(error: error)
    }
    
   
    // MARK: - Server call for User Details data
    func getUserDetailsDataFromServer(delegate:UserDetailsViewModelProtocol) -> Void {
        self.delegate = delegate
        APIHelper.shared.mainServerdelegate = self
        
        let url = "https://run.mocky.io/v3/aaf97364-eedc-46a5-8f9e-56eb4b3cedd2"
        APIHelper.shared.getCallWithAlamofire(serverUrl: url)
    }
    
    // MARK: - Parse User Details data
    func parseUserDetailsData(completion: @escaping ((UserProfileDataModel?, String) -> Void) , responseData:Any) {
        if let jsonModel =  Mapper<UserProfileDataModel>().map(JSONObject: responseData ){
            completion(jsonModel, "Success")
        }
    }
}


//
//  UserProfileModel.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import ObjectMapper

// MARK: - User Details Model
class UserProfileDataModel: Mappable {
    
    var id: String?
    var username:String?
    var firstname:String?
    var lastName:String?
    var dob:String?
    var address:String?
    var pointsEarned:String?
    var walletBalance:String?
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        id <- map["id"]
        username <- map["username"]
        firstname <- map["firstname"]
        lastName <- map["lastName"]
        dob <- map["dob"]
        address <- map["address"]
        pointsEarned <- map["pointsEarned"]
        walletBalance <- map["walletBalance"]
    }
}

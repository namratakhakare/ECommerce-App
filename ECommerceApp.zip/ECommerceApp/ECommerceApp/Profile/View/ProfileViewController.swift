//
//  ProfileViewController.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import UIKit
import Foundation

class ProfileViewController: UIViewController, UserDetailsViewModelProtocol {

    @IBOutlet weak var viewBase: UIView!
    @IBOutlet weak var viewNavigation: UIView!
    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var viewWalletBalance: UIView!
    @IBOutlet weak var lblWalletBalanceTitle: UILabel!
    @IBOutlet weak var lblWalletBalanceAmount: UILabel!
    @IBOutlet weak var viewEarnedPoints: UIView!
    @IBOutlet weak var lblEarnedPointsTitle: UILabel!
    @IBOutlet weak var lblEarnedPointsAmount: UILabel!
    @IBOutlet weak var lblFName: UILabel!
    @IBOutlet weak var txtFName: UITextField!
    @IBOutlet weak var lblLName: UILabel!
    @IBOutlet weak var txtLName: UITextField!
    @IBOutlet weak var lblDOB: UILabel!
    @IBOutlet weak var txtDOB: UITextField!
    @IBOutlet weak var lblAddressTitle: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
    var userData: UserProfileDataModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewNavigation.addShadowForView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.getUserDetailsData()
    }
    
    // MARK: -  UISettings
    func doInitialize(){
        if let userName = self.userData?.username {
            self.lblUserName.text = userName
        }
        if let firstName = self.userData?.firstname {
            self.txtFName.text = firstName
        }
        if let lastName = self.userData?.lastName {
            self.txtLName.text = lastName
        }
        if let lastName = self.userData?.dob {
            self.txtDOB.text = lastName
        }
        if let address = self.userData?.address {
            self.lblAddress.text = address
        }
        if let earnedPoints = self.userData?.pointsEarned {
            self.lblEarnedPointsAmount.text = earnedPoints
        }
        if let walletBalance = self.userData?.walletBalance {
            self.lblWalletBalanceAmount.text = walletBalance
        }
    }
    
    // MARK: -  Get Product List From Server
    func getUserDetailsData() {
        DispatchQueue.main.async {
            UserProfileViewModel.sharedInstance.getUserDetailsDataFromServer(delegate: self)
        }
    }
    
    // MARK: - User Details ViewModel DELEGATE
    func didFetchUserDetailsData(responseData:Any) ->  Void{
        UserProfileViewModel.sharedInstance.parseUserDetailsData(completion: { (userData, message) in
            DispatchQueue.main.async {
                if let data = userData{
                    self.userData = data
                    print("ProfileData:: \(String(describing: self.userData))")
                    self.doInitialize()
                }
            }
        }, responseData: responseData)
    }
    
    func didFailUserDetailsDataWithError(error:NSError) -> Void{
        // show error message
        DispatchQueue.main.async{
            // stop sppinner
            //Failure
        }
    }
}

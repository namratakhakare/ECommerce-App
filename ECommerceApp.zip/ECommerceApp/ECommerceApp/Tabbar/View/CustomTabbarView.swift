//
//  CustomTabbarView.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import UIKit

class CustomeTabBarController: UITabBarController, UITabBarControllerDelegate {
    
    // MARK: - View life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
       doInitialize()
    }
    // MARK: - User Functions
    func doInitialize() {
        
        self.navigationController?.navigationBar.isHidden = true
        // tabbar setup
        self.tabBar.items?[0].title = "Product List"
        self.tabBar.items?[1].title = "Profile"
        
        self.tabBar.tintColor = UIColor(hexFromString: "FFACB6")
        UITabBar.appearance().barTintColor = UIColor.white
        UITabBar.appearance().clipsToBounds = true
        UITabBar.appearance().backgroundColor = UIColor.white
    }
        
    // MARK: - TabBarController Delegates
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        if self.selectedIndex != 0 {
            UIGraphicsBeginImageContextWithOptions(self.view.frame.size, true, 0)
            let context = UIGraphicsGetCurrentContext()!
            view.layer.render(in: context)
            UIGraphicsEndImageContext()
        }
        return true
    }

    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard let barItemView = item.value(forKey: "view") as? UIView else { return }
        let timeInterval: TimeInterval = 0.3
        let propertyAnimator = UIViewPropertyAnimator(duration: timeInterval, dampingRatio: 0.5) {
            barItemView.transform = CGAffineTransform.identity.scaledBy(x: 0.9, y: 0.9)
        }
        propertyAnimator.addAnimations({ barItemView.transform = .identity }, delayFactor: CGFloat(timeInterval))
        propertyAnimator.startAnimation()
    }
    
}

//
//  ProductListViewModel.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import ObjectMapper

@objc protocol ProductListViewModelProtocol
{
    @objc optional
    func didFetchProductListData(responseData: Any) -> Void
    @objc optional
    func didFailProductListDataWithError(error: NSError) -> Void
}

class ProductListViewModel : AppMainServiceDelegate {
    
    weak var delegate:ProductListViewModelProtocol?
    var message = ""
    
    static let sharedInstance :ProductListViewModel =
    {
        let instance = ProductListViewModel()
        return instance
    }()
    
    func didFetchData(responseData: Any) {
        self.delegate?.didFetchProductListData?(responseData: responseData)
    }
    
    func didFailWithError(error: NSError) {
        self.delegate?.didFailProductListDataWithError?(error: error)
    }
    
   
    // MARK: - Server call for Product List data
    func getProductListDataFromServer(delegate:ProductListViewModelProtocol) -> Void {
        self.delegate = delegate
        APIHelper.shared.mainServerdelegate = self
        
        let url = "https://run.mocky.io/v3/bc09a745-4346-4025-9611-9da76366dbbc"
        APIHelper.shared.getCallWithAlamofire(serverUrl: url)
    }
    
    // MARK: - Parse Product List data
    func parseProductListData(completion: @escaping ((ProductListProductModel?, String) -> Void) , responseData:Any) {
        if let jsonModel =  Mapper<ProductListMainModel>().map(JSONObject: responseData ) {
            if let productData = jsonModel.data {
                completion(productData, "Success")
            }
        }
    }
    
}

//
//  ProductListViewController.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import UIKit
import Foundation

class ProductListViewController: UIViewController, ProductListViewModelProtocol {

    // MARK: - Outlets
    @IBOutlet weak var viewNavigaton: UIView!
    @IBOutlet weak var titleNavigation: UILabel!
    @IBOutlet weak var viewBase: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    var productList = [ProductListArray]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.doInitialize()
        self.getProductList()
    }
    
    func doInitialize(){
        self.viewNavigaton.backgroundColor = .white
        self.viewNavigaton.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.viewNavigaton.layer.shadowOpacity = 0.6
        self.viewNavigaton.layer.shadowRadius = 3.0
        self.viewNavigaton.layer.shadowColor =  ColorCode.shadowColor.colorWithHexString(hex: ColorCode.shadowColor).cgColor
    }
    
    
    // MARK: -  Get Product List From Server
    func getProductList() {
        DispatchQueue.main.async {
            ProductListViewModel.sharedInstance.getProductListDataFromServer(delegate: self)
        }
    }
    
    // MARK: - Product List ViewModel DELEGATE
    func didFetchProductListData(responseData:Any) ->  Void {
        ProductListViewModel.sharedInstance.parseProductListData(completion: { (productListData, message) in
            DispatchQueue.main.async {
                if let productArr = productListData?.products {
                    self.productList = productArr
                }
                self.tableView.reloadData()
            }
        }, responseData: responseData)
    }
    
    func didFailProductListDataWithError(error:NSError) -> Void{
        // show error message
        DispatchQueue.main.async{
            // stop sppinner
            //Failure
        }
    }
}

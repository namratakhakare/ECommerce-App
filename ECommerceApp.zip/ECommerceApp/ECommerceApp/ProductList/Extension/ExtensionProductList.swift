//
//  ExtensionProductList.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import UIKit
import SDWebImage

extension ProductListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.productList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "GetRewardsTableViewCell", for: indexPath) as! GetRewardsTableViewCell
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductListTableViewCell", for: indexPath) as! ProductListTableViewCell
            if let image = self.productList[indexPath.row].productUrl{
                cell.imgProduct.sd_setImage(with: URL(string:image))
            }
            if let name = self.productList[indexPath.row].name {
                cell.lblProductName.text = name
            }
            if let brandName = self.productList[indexPath.row].brand {
                cell.lblBrandName.text = brandName
            }
            if let description = self.productList[indexPath.row].productDesc {
                cell.lblDescription.text = description
            }
            if let price = self.productList[indexPath.row].price {
                cell.lblPrice.text = price
            }
            cell.lblPrice.addSlantLine(slantLineColor: .gray, slantLineWidth: 1, startPoint:CGPoint(x: cell.lblPrice.frame.width, y: 2), endPoint: CGPoint(x: 0, y: cell.lblPrice.frame.height - 2))
            
            if let offerPrice = self.productList[indexPath.row].offerPrice {
                cell.lblOfferPrice.text = "₹ " + offerPrice
            }
            cell.imgProduct.layer.cornerRadius = 8
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 1 {
            showToast(message: "Thank you for joining our rewards program")
        } else {
            let viewController = Storyboard.ProductDetailsStoryboard.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
            viewController.recommendedProducts = self.productList
            viewController.selectedProductAtIndex = indexPath.row
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
}

//
//  ProductListTableViewCell.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import UIKit

class ProductListTableViewCell: UITableViewCell {

    // MARK: - Outlets
    @IBOutlet weak var viewBase: UIView!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblBrandName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblOfferPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DispatchQueue.main.async {
            self.viewBase.addShadowForView()
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

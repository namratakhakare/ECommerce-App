//
//  ProductListModel.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import ObjectMapper

// MARK: - LabelDataModel
class ProductListMainModel: Mappable{
    var data: ProductListProductModel?
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        data <- map["data"]
    }
}

// MARK: - DataClass
class ProductListProductModel: Mappable {
    var products: [ProductListArray]?
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        products <- map["products"]
    }
    
}

// MARK: - Product
class ProductListArray: Mappable{
   var id: String?
    var brand: String?
    var name: String?
    var productDesc: String?
    var price: String?
    var offerPrice: String?
    var productUrl: String?
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        id <- map["id"]
        brand <- map["brand"]
        name <- map["name"]
        productDesc <- map["productDesc"]
        price <- map["price"]
        offerPrice <- map["offerPrice"]
        productUrl <- map["productUrl"]
    }
    
    
}

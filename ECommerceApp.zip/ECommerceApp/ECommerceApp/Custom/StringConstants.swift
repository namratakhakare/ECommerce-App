//
//  StringConstants.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import UIKit

// MARK: - Font Type
struct FontType {
    static let OpenSansRegular    = "OpenSans-Regular"
    static let OpenSansSemiBold   = "OpenSans-SemiBold"
    static let OpenSansMedium     = "OpenSans-Medium"
    static let OpenSansBold       = "OpenSans-Bold"
    static let FigtreeRegular     = "Figtree-Regular"
    static let FigtreeBold        = "Figtree-Bold"
    static let FigtreeSemiBold    = "Figtree-SemiBold"
    static let FigtreeBlack       = "Figtree-Black"
}

struct ColorCode {
    static let shadowColor    = "#F0F0F0"
}

// MARK: - Storyboards
struct Storyboard {
    static var ProductList: UIStoryboard {
        return UIStoryboard(name: "ProductList", bundle: Bundle.main)
    }
    static var LoginStoryboard: UIStoryboard {
        return UIStoryboard(name: "LoginStoryboard", bundle: Bundle.main)
    }
    static var tabbar: UIStoryboard {
        return UIStoryboard(name: "Tabbar", bundle: Bundle.main)
    }
    static var ProductDetailsStoryboard: UIStoryboard {
        return UIStoryboard(name: "ProductDetailsStoryboard", bundle: Bundle.main)
    }
}

//
//  Extension+String.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import Foundation
import UIKit

extension String {
    // MARK: - Converting String into Hex Code
    func colorWithHexString (hex: String) -> UIColor {
        var cString: String = hex.trimmingCharacters(in: NSCharacterSet.whitespaces).uppercased()
        if cString.hasPrefix("#") {
            cString = String(cString.dropFirst())
        }
        if cString.count != 6 {
            return UIColor.gray
        }
        let rString = String(cString[cString.index(cString.startIndex, offsetBy: 0)..<cString.index(cString.endIndex, offsetBy: -4)])
        let gString = String(cString[cString.index(cString.startIndex, offsetBy: 2)..<cString.index(cString.endIndex, offsetBy: -2)])
        let bString = String(cString[cString.index(cString.startIndex, offsetBy: 4)..<cString.index(cString.endIndex, offsetBy: -0)])
        var rValue: CUnsignedInt = 0, gValue: CUnsignedInt = 0, bValue: CUnsignedInt = 0
        Scanner(string: rString).scanHexInt32(&rValue)
        Scanner(string: gString).scanHexInt32(&gValue)
        Scanner(string: bString).scanHexInt32(&bValue)
        return UIColor(red: CGFloat(Float(rValue) / 255.0),
                       green: CGFloat(Float(gValue) / 255.0),
                       blue: CGFloat(Float(bValue) / 255.0),
                       alpha: CGFloat(Float(1)))
    }
}

//
//  ExtensionViewController.swift
//  ECommerceApp
//
//  Created by APPLE on 2/5/23.
//

import Foundation
import UIKit

extension UIViewController{
    
// MARK: - Creating Toast Message in all Views */
    func showToast(message : String) {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 150, y: self.view.frame.size.height-160, width: 300, height: 35))
        toastLabel.backgroundColor = "EAECEE".colorWithHexString(hex: "EAECEE")
        toastLabel.textColor = "0E0001".colorWithHexString(hex: "0E0001")
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: "Figtree-Regular", size: 14.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 16;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
      
        UIView.animate(withDuration: 8.0, delay: 0.3, options: .curveEaseOut, animations: {
                   toastLabel.alpha = 0.0
               }, completion: {(isCompleted) in
                   toastLabel.removeFromSuperview()
               })
    }
}

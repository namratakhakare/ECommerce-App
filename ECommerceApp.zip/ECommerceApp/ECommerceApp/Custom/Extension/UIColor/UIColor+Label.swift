//
//  UIColor.swift
//  ECommerceApp
//
//  Created by APPLE on 04/02/23.
//

import Foundation
import UIKit.UIColor
extension UIColor {
    convenience init(hexFromString:String, alpha:CGFloat = 1.0) {
        var cString:String = hexFromString.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        var rgbValue:UInt32 = 10066329 //color #999999 if string has wrong format
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) == 6) {
            Scanner(string: cString).scanHexInt32(&rgbValue)
        }
        
        self.init(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: alpha
        )
    }
}

extension UILabel {
    func addSlantLine(slantLineColor: UIColor, slantLineWidth:CGFloat, startPoint: CGPoint, endPoint: CGPoint) {
        let slantLinePath = UIBezierPath()
        slantLinePath.move(to: startPoint)
        slantLinePath.addLine(to: endPoint)

        let slantLineLayer = CAShapeLayer()
        slantLineLayer.path = slantLinePath.cgPath
        slantLineLayer.lineWidth = slantLineWidth
        slantLineLayer.strokeColor = slantLineColor.cgColor
        layer.addSublayer(slantLineLayer)
    }
}

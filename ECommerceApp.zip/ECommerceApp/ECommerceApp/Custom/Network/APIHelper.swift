//
//  APIHelper.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import UIKit
import Alamofire

// MARK: - App Man Service Delegate For Fetch Success or Failure Data
@objc protocol AppMainServiceDelegate: AnyObject {
    func didFetchData(responseData: Any)
    func didFailWithError(error: NSError)
}

class APIHelper: NSObject {
    // MARK: - Properties
    
    static let shared =  APIHelper()
    private override init() {}

    weak var mainServerdelegate: AppMainServiceDelegate?
    
    
// MARK: - Get Call Through Alamofire
   
    func getCallWithAlamofire(serverUrl: String) {
        
        print(serverUrl)
       let localHeaders: HTTPHeaders = [
           "Accept": "application/json",
           "Content-Type": "application/x-www-form-urlencoded"
       ]
    let urlString = serverUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? serverUrl
           
       AF.request(urlString, method: .get, parameters: nil ,encoding: URLEncoding.default, headers:localHeaders).responseJSON {  response in
           switch response.result {
           case let .success(value):
               self.mainServerdelegate?.didFetchData(responseData: value)
               print("JSON: \(value)") // serialized json response
               return
           case let .failure(error):
               print(error.localizedDescription)
               self.mainServerdelegate?.didFailWithError(error: error as NSError)
               return
           }
       }
   }
}

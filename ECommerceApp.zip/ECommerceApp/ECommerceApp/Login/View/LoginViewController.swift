//
//  LoginViewController.swift
//  ECommerceApp
//
//  Created by APPLE on 2/4/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var txtUsername: FloatLabelTextField!
    @IBOutlet weak var txtPassword: FloatLabelTextField!
    @IBOutlet weak var btnLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.btnLogin.layer.cornerRadius = 8
    }
    
    @IBAction func btnLoginClicked(_ sender: UIButton){
        if self.txtUsername.text == ""{
            showToast(message: "Please enter Username")
        }
        else if txtPassword.text == ""{
           showToast(message: "Please enter Password")
        }
        else {
            let navObj = Storyboard.tabbar.instantiateViewController(withIdentifier: "CustomeTabBarController") as! CustomeTabBarController
            self.navigationController?.pushViewController(navObj, animated: true)
        }
    }
}

//
//  LaunchViewController.swift
//  ECommerceApp
//
//  Created by APPLE on 2/5/23.
//

import UIKit

class LaunchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            let navObj = Storyboard.LoginStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(navObj, animated: true)
        }
    }
}
